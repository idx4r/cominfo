package com.gdupt.cominfo.pojo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Goods implements Serializable {
	private Integer pk_goodsid;
	private String goodsName;
	private String goodsContent;
	private String goodsType;
	private Integer goodsPoint;
	private Integer redeemNum;
	private Integer goodsState;
	private String goodsPicture;
	private Integer goodsCollect;
	public Integer getPk_goodsid() {
		return pk_goodsid;
	}
	public void setPk_goodsid(Integer pk_goodsid) {
		this.pk_goodsid = pk_goodsid;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getGoodsContent() {
		return goodsContent;
	}
	public void setGoodsContent(String goodsContent) {
		this.goodsContent = goodsContent;
	}
	public String getGoodsType() {
		return goodsType;
	}
	public void setGoodsType(String goodsType) {
		this.goodsType = goodsType;
	}
	public Integer getGoodsPoint() {
		return goodsPoint;
	}
	public void setGoodsPoint(Integer goodsPoint) {
		this.goodsPoint = goodsPoint;
	}
	public Integer getRedeemNum() {
		return redeemNum;
	}
	public void setRedeemNum(Integer redeemNum) {
		this.redeemNum = redeemNum;
	}
	public Integer getGoodsState() {
		return goodsState;
	}
	public void setGoodsState(Integer goodsState) {
		this.goodsState = goodsState;
	}
	public String getGoodsPicture() {
		return goodsPicture;
	}
	public void setGoodsPicture(String goodsPicture) {
		this.goodsPicture = goodsPicture;
	}
	public Integer getGoodsCollect() {
		return goodsCollect;
	}
	public void setGoodsCollect(Integer goodsCollect) {
		this.goodsCollect = goodsCollect;
	}


	
	
}
