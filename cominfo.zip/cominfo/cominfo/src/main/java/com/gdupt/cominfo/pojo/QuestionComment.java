package com.gdupt.cominfo.pojo;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;

@ApiModel(value="QuestionComment",description="问题评论对象")
@SuppressWarnings("serial")
public class QuestionComment implements Serializable {
	private Integer pk_qcid;
	private Integer quesid;
	private String qcTime;
	private String qcContent;
	private Integer qcUserid;
	private Users qcUser;
	private Integer qcLike;
	private Integer qcReply;
	private List<QuestionReply> qcReplyList;
	private Integer qcState;
	public Integer getPk_qcid() {
		return pk_qcid;
	}
	public void setPk_qcid(Integer pk_qcid) {
		this.pk_qcid = pk_qcid;
	}
	public Integer getQuesid() {
		return quesid;
	}
	public void setQuesid(Integer quesid) {
		this.quesid = quesid;
	}
	public String getQcTime() {
		return qcTime;
	}
	public void setQcTime(String qcTime) {
		this.qcTime = qcTime;
	}
	public String getQcContent() {
		return qcContent;
	}
	public void setQcContent(String qcContent) {
		this.qcContent = qcContent;
	}
	public Integer getQcUserid() {
		return qcUserid;
	}
	public void setQcUserid(Integer qcUserid) {
		this.qcUserid = qcUserid;
	}
	public Users getQcUser() {
		return qcUser;
	}
	public void setQcUser(Users qcUser) {
		this.qcUser = qcUser;
	}
	public Integer getQcLike() {
		return qcLike;
	}
	public void setQcLike(Integer qcLike) {
		this.qcLike = qcLike;
	}
	public Integer getQcReply() {
		return qcReply;
	}
	public void setQcReply(Integer qcReply) {
		this.qcReply = qcReply;
	}
	public List<QuestionReply> getQcReplyList() {
		return qcReplyList;
	}
	public void setQcReplyList(List<QuestionReply> qcReplyList) {
		this.qcReplyList = qcReplyList;
	}
	public Integer getQcState() {
		return qcState;
	}
	public void setQcState(Integer qcState) {
		this.qcState = qcState;
	}
	

	
}
