package com.gdupt.cominfo.dao;

import java.util.List;

import com.gdupt.cominfo.pojo.Goods;

public interface ShopMapper {

	public List<Goods> getGoodsList();
	
	public Goods getGoodsById(Integer pk_goodsid);
}
