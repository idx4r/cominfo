package com.gdupt.cominfo.pojo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Receive implements Serializable {
	private Integer pk_receiveid;
	private Integer receiveUserid;
	private String receiveName;
	private String receiveNumber;
	private String receiveAddress;
	private Integer receiveState;
	public Integer getPk_receiveid() {
		return pk_receiveid;
	}
	public void setPk_receiveid(Integer pk_receiveid) {
		this.pk_receiveid = pk_receiveid;
	}
	public Integer getReceiveUserid() {
		return receiveUserid;
	}
	public void setReceiveUserid(Integer receiveUserid) {
		this.receiveUserid = receiveUserid;
	}
	public String getReceiveName() {
		return receiveName;
	}
	public void setReceiveName(String receiveName) {
		this.receiveName = receiveName;
	}
	public String getReceiveNumber() {
		return receiveNumber;
	}
	public void setReceiveNumber(String receiveNumber) {
		this.receiveNumber = receiveNumber;
	}
	public String getReceiveAddress() {
		return receiveAddress;
	}
	public void setReceiveAddress(String receiveAddress) {
		this.receiveAddress = receiveAddress;
	}
	public Integer getReceiveState() {
		return receiveState;
	}
	public void setReceiveState(Integer receiveState) {
		this.receiveState = receiveState;
	}
	

}
