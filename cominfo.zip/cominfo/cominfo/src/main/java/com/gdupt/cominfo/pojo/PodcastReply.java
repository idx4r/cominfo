package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;

@ApiModel(value="PodcastReply",description="文章回复对象")
@SuppressWarnings("serial")
public class PodcastReply implements Serializable{
	private Integer pk_prid;
	private Integer pcid;
	private String prContent;
	private Integer prUserid;
	private String prUserName;
	private Integer prUseredid;
	private String prUseredName;
	private String prTime;
	private Integer prState;
	private Integer podid;
	private String pcContent;
	public Integer getPk_prid() {
		return pk_prid;
	}
	public void setPk_prid(Integer pk_prid) {
		this.pk_prid = pk_prid;
	}
	public Integer getPcid() {
		return pcid;
	}
	public void setPcid(Integer pcid) {
		this.pcid = pcid;
	}
	public String getPrContent() {
		return prContent;
	}
	public void setPrContent(String prContent) {
		this.prContent = prContent;
	}
	public Integer getPrUserid() {
		return prUserid;
	}
	public void setPrUserid(Integer prUserid) {
		this.prUserid = prUserid;
	}
	public String getPrUserName() {
		return prUserName;
	}
	public void setPrUserName(String prUserName) {
		this.prUserName = prUserName;
	}
	public Integer getPrUseredid() {
		return prUseredid;
	}
	public void setPrUseredid(Integer prUseredid) {
		this.prUseredid = prUseredid;
	}
	public String getPrUseredName() {
		return prUseredName;
	}
	public void setPrUseredName(String prUseredName) {
		this.prUseredName = prUseredName;
	}
	public String getPrTime() {
		return prTime;
	}
	public void setPrTime(String prTime) {
		this.prTime = prTime;
	}
	public Integer getPrState() {
		return prState;
	}
	public void setPrState(Integer prState) {
		this.prState = prState;
	}
	public Integer getPodid() {
		return podid;
	}
	public void setPodid(Integer podid) {
		this.podid = podid;
	}
	public String getPcContent() {
		return pcContent;
	}
	public void setPcContent(String pcContent) {
		this.pcContent = pcContent;
	}


}