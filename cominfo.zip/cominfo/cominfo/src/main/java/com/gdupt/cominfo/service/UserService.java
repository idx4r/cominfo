package com.gdupt.cominfo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdupt.cominfo.dao.UserMapper;
import com.gdupt.cominfo.pojo.Apply;
import com.gdupt.cominfo.pojo.Collect;
import com.gdupt.cominfo.pojo.Data;
import com.gdupt.cominfo.pojo.Podcast;
import com.gdupt.cominfo.pojo.PodcastReply;
import com.gdupt.cominfo.pojo.Point;
import com.gdupt.cominfo.pojo.Question;
import com.gdupt.cominfo.pojo.Receive;
import com.gdupt.cominfo.pojo.Resource;
import com.gdupt.cominfo.pojo.Users;

@Service
public class UserService {

	@Autowired
	private UserMapper userMapper;

	public List<Users> getUserList() {
		return userMapper.getUserList();
	}

	public Users getUserById(Integer pk_userid) {
		return userMapper.getUserById(pk_userid);
	}

	public Integer addUserInfo(Users user) {
		return userMapper.addUserInfo(user);
	}

	public Integer editUserInfo(Users user) {
		return userMapper.editUserInfo(user);
	}

	public Integer removeUserInfo(Integer pk_userid) {
		return userMapper.removeUserInfo(pk_userid);
	}

	public List<Podcast> getUserPodcastById(Integer pk_userid) {
		return userMapper.getUserPodcastById(pk_userid);
	}

	public Integer removeUserPodById(Integer pk_podid) {
		return userMapper.removeUserPodById(pk_podid);
	}

	public List<Podcast> getUserDelPodById(Integer pk_userid) {
		return userMapper.getUserDelPodById(pk_userid);
	}

	public Integer editUserDelPodById(Integer pk_podid) {
		return userMapper.editUserDelPodById(pk_podid);
	}

	public List<Question> getUserQuestionById(Integer pk_userid) {
		return userMapper.getUserQuestionById(pk_userid);
	}

	public Integer removeUserQuesById(int pk_quesid) {
		return userMapper.removeUserQuesById(pk_quesid);
	}

	public List<Question> getUserDelQuesById(int pk_userid) {
		return userMapper.getUserDelQuesById(pk_userid);
	}

	public Integer editUserDelQuesById(Integer pk_quesid) {
		return userMapper.editUserDelQuesById(pk_quesid);
	}

	public Users checkUserAndPwd(String userName, String password) {
		return userMapper.checkUserAndPwd(userName, password);
	}

	public Users checkUserIsExist(String userName) {
		return userMapper.checkUserIsExist(userName);
	}

	public Users checkPasswordIsRight(Integer pk_userid, String password) {
		return userMapper.checkPasswordIsRight(pk_userid, password);
	}

	public Integer editUserPasswordById(Integer pk_userid, String password) {
		return userMapper.editUserPasswordById(pk_userid, password);
	}

	public List<PodcastReply> getUserPodReplyById(Integer prUseredid) {
		return userMapper.getUserPodReplyById(prUseredid);
	}

	public Integer addPodcast(Podcast podcast) {
		return userMapper.addPodcast(podcast);
	}

	public Integer addQuestion(Question question) {
		return userMapper.addQuestion(question);
	}

	public List<Resource> getUserResourceById(Integer resourceUserid) {
		return userMapper.getUserResourceById(resourceUserid);
	}
	
	public List<Question> getUserInvitedById(Integer inviteUserid){
		return userMapper.getUserInvitedById(inviteUserid);
	}
	
	public Integer addApply(Apply apply) {
		return userMapper.addApply(apply);
	}
	
	
	public Integer removeResourceInfo(Integer pk_resourceid) {
		return userMapper.removeResourceInfo(pk_resourceid);
	}
	
	public Integer editUserDelResourceById(Integer pk_resourceid) {
		return userMapper.editUserDelResourceById(pk_resourceid);
	}
	
	public Integer addResourceInfo(Resource resource) {
		return userMapper.addResourceInfo(resource);
	}
	
	public Data getUserPodDataById(Integer pk_userid) {
		return userMapper.getUserPodDataById(pk_userid);
	}
	
	public Data getUserQuesDataById(Integer pk_userid) {
		return userMapper.getUserQuesDataById(pk_userid);
	}
	
	public Data getUserResourceDataById(Integer pk_userid) {
		return userMapper.getUserResourceDataById(pk_userid);
	}
	
	public Integer removePodCollectNum(Integer pk_podid) {
		return userMapper.removePodCollectNum(pk_podid);
	}
	
	public Integer removeQuesCollectNum(Integer pk_quesid) {
		return userMapper.removeQuesCollectNum(pk_quesid);
	}
	
	public Integer removeResourceCollectNum(Integer pk_resourceid) {
		return userMapper.removeResourceCollectNum(pk_resourceid);
	}
	
	public Integer removeGoodsCollectNum(Integer pk_goodsid) {
		return userMapper.removeGoodsCollectNum(pk_goodsid);
	}
	
	public Integer removeCollect(Collect collect) {
		return userMapper.removeCollect(collect);
	}
	
	public Integer addPodCollectNum(Integer pk_podid) {
		return userMapper.addPodCollectNum(pk_podid);
	}
	
	public Integer addQuesCollectNum(Integer pk_quesid) {
		return userMapper.addQuesCollectNum(pk_quesid);
	}
	
	public Integer addResourceCollectNum(Integer pk_resourceid) {
		return userMapper.addResourceCollectNum(pk_resourceid);
	}
	
	public Integer addGoodsCollectNum(Integer pk_goodsid) {
		return userMapper.addGoodsCollectNum(pk_goodsid);
	}
	
	public Integer addCollect(Collect collect) {
		return userMapper.addCollect(collect);
	}
	
	public Collect checkUserCollectIsExist(Collect collect) {
		return userMapper.checkUserCollectIsExist(collect);
	}
	
	public Integer addRecoverCollect(Collect collect) {
		return userMapper.addRecoverCollect(collect);
	}
	
	public List<Collect> getUserCollectById(Integer pk_userid,Integer collectTypeid){
		return userMapper.getUserCollectById(pk_userid,collectTypeid);
	}
	
	public List<Point> getUserPointById(Integer pk_userid){
		return userMapper.getUserPointById(pk_userid);
	}
	
	public List<Receive> getUserReceiveById(Integer pk_userid){
		return userMapper.getUserReceiveById(pk_userid);
	}
	
	public Receive getReceiveById(Integer pk_receiveid) {
		return userMapper.getReceiveById(pk_receiveid);
	}
	
	public int addReceiveInfo(Receive receive) {
		return userMapper.addReceiveInfo(receive);
	}
	
	public int editReceiveInfo(Receive receive) {
		return userMapper.editReceiveInfo(receive);
	}
	
	public int removeReceiveInfo(Integer pk_receiveid) {
		return userMapper.removeReceiveInfo(pk_receiveid);
	}

}
