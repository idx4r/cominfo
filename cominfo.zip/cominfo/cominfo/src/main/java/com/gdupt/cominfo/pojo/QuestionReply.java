package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;

@ApiModel(value="QuestionReply",description="问题回复对象")
@SuppressWarnings("serial")
public class QuestionReply implements Serializable {
	private Integer pk_qrid;
	private Integer qcid;
	private String qrContent;
	private Integer qrUserid;
	private Users qrUser;
	private Integer qrUseredid;
	private Users qrUsered;
	private String qrTime;
	private Integer qrState;
	public Integer getPk_qrid() {
		return pk_qrid;
	}
	public void setPk_qrid(Integer pk_qrid) {
		this.pk_qrid = pk_qrid;
	}
	public Integer getQcid() {
		return qcid;
	}
	public void setQcid(Integer qcid) {
		this.qcid = qcid;
	}
	public String getQrContent() {
		return qrContent;
	}
	public void setQrContent(String qrContent) {
		this.qrContent = qrContent;
	}
	public Integer getQrUserid() {
		return qrUserid;
	}
	public void setQrUserid(Integer qrUserid) {
		this.qrUserid = qrUserid;
	}
	public Users getQrUser() {
		return qrUser;
	}
	public void setQrUser(Users qrUser) {
		this.qrUser = qrUser;
	}
	public Integer getQrUseredid() {
		return qrUseredid;
	}
	public void setQrUseredid(Integer qrUseredid) {
		this.qrUseredid = qrUseredid;
	}
	public Users getQrUsered() {
		return qrUsered;
	}
	public void setQrUsered(Users qrUsered) {
		this.qrUsered = qrUsered;
	}
	public String getQrTime() {
		return qrTime;
	}
	public void setQrTime(String qrTime) {
		this.qrTime = qrTime;
	}
	public Integer getQrState() {
		return qrState;
	}
	public void setQrState(Integer qrState) {
		this.qrState = qrState;
	}
	

	
}
