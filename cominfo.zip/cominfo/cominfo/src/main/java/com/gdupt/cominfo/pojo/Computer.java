package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;

@ApiModel(value="Computer",description="计算机对象")
@SuppressWarnings("serial")
public class Computer implements Serializable{
	private Integer pk_computerid;
	private String computerName;
	private Integer modelTypeid;
	private String modelType;
	private String computerNews;
	private String suit;
	private double price;
	private Integer produceTypeid;
	private String produceType;
	private Integer publishUserid;
	private Users publishUser;
	private String publishTime;
	private Integer computerState;
	
	public Integer getPk_computerid() {
		return pk_computerid;
	}
	public void setPk_computerid(Integer pk_computerid) {
		this.pk_computerid = pk_computerid;
	}
	public String getComputerName() {
		return computerName;
	}
	public void setComputerName(String computerName) {
		this.computerName = computerName;
	}
	public Integer getModelTypeid() {
		return modelTypeid;
	}
	public void setModelTypeid(Integer modelTypeid) {
		this.modelTypeid = modelTypeid;
	}
	public String getModelType() {
		return modelType;
	}
	public void setModelType(String modelType) {
		this.modelType = modelType;
	}
	public String getComputerNews() {
		return computerNews;
	}
	public void setComputerNews(String computerNews) {
		this.computerNews = computerNews;
	}
	public String getSuit() {
		return suit;
	}
	public void setSuit(String suit) {
		this.suit = suit;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Integer getProduceTypeid() {
		return produceTypeid;
	}
	public void setProduceTypeid(Integer produceTypeid) {
		this.produceTypeid = produceTypeid;
	}
	public String getProduceType() {
		return produceType;
	}
	public void setProduceType(String produceType) {
		this.produceType = produceType;
	}
	public Integer getPublishUserid() {
		return publishUserid;
	}
	public void setPublishUserid(Integer publishUserid) {
		this.publishUserid = publishUserid;
	}
	public Users getPublishUser() {
		return publishUser;
	}
	public void setPublishUser(Users publishUser) {
		this.publishUser = publishUser;
	}
	public String getPublishTime() {
		return publishTime;
	}
	public void setPublishTime(String publishTime) {
		this.publishTime = publishTime;
	}
	public Integer getComputerState() {
		return computerState;
	}
	public void setComputerState(Integer computerState) {
		this.computerState = computerState;
	}
	
	
}
