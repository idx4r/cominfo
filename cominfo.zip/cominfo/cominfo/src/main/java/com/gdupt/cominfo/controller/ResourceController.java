package com.gdupt.cominfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.gdupt.cominfo.pojo.Resource;
import com.gdupt.cominfo.service.ResourceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "大学生共享资源平台")
@RestController
public class ResourceController {
	@Autowired
	private ResourceService resourceService;

	/**
	 * 查询所有资源信息，使用get方法
	 */
	@ApiOperation(value = "资源列表", notes = "获取所有资源信息")
	@GetMapping("/getResourceList")
	public List<Resource> getResourceList() {
		List<Resource> resourceList = resourceService.getResourceList();
		return resourceList;
	}
	
	/**
	 * 按下载量排序，使用get方法
	 */
	@ApiOperation(value = "资源排序Download", notes = "按下载量排序所有资源信息")
	@GetMapping("/getResourceListByDownload")
	public List<Resource> getResourceListByDownload() {
		List<Resource> resourceList = resourceService.getResourceListByDownload();
		return resourceList;
	}
	
	/**
	 * 按时间排序，使用get方法
	 */
	@ApiOperation(value = "资源排序Time", notes = "按时间排序所有资源信息")
	@GetMapping("/getResourceListByTime")
	public List<Resource> getResourceListByTime() {
		List<Resource> resourceList = resourceService.getResourceListByTime();
		return resourceList;
	}

	/**
	 * 按id查询资源信息，使用get方法
	 */
	@ApiOperation(value = "资源信息", notes = "获取对应id资源信息")
	@GetMapping("/getResource/{pk_resourceid}")
	public Resource getResourceById(
			@ApiParam(name = "pk_resourceid", value = "资源id", required = true) @PathVariable("pk_resourceid") int pk_resourceid) {
		Resource resourceInfo = resourceService.getResourceById(pk_resourceid);
		return resourceInfo;
	}
	
	/**
	 * 按title模糊查询资源信息，使用get方法
	 */
	@ApiOperation(value = "查询资源Title", notes = "获取对应title资源信息")
	@GetMapping("/getResourceByTitle/{resourceTitle}")
	public List<Resource> getResourceByTitle(
			@ApiParam(name = "resourceTitle", value = "资源title", required = true) @PathVariable("resourceTitle") String resourceTitle) {
		List<Resource> resourceInfo = resourceService.getResourceByTitle(resourceTitle);
		return resourceInfo;
	}
	
	/**
	 * 按type模糊查询资源信息，使用get方法
	 */
	@ApiOperation(value = "查询资源Type", notes = "获取对应type资源信息")
	@GetMapping("/getResourceByType/{resourceType}")
	public List<Resource> getResourceByType(
			@ApiParam(name = "resourceType", value = "资源type", required = true) @PathVariable("resourceType") String resourceType) {
		List<Resource> resourceInfo = resourceService.getResourceByType(resourceType);
		return resourceInfo;
	}
}
