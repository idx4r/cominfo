package com.gdupt.cominfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.gdupt.cominfo.pojo.Goods;
import com.gdupt.cominfo.service.ShopService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "积分商城")
@RestController
public class ShopController {
	@Autowired
	private ShopService shopService;

	/**
	 * 查询所有商品信息，使用get方法
	 */
	@ApiOperation(value = "商品列表", notes = "获取所有商品信息")
	@GetMapping("/getGoodsList")
	public List<Goods> getGoodsList() {
		List<Goods> goodsList = shopService.getGoodsList();
		return goodsList;
	}

	/**
	 * 按id查询商品信息，使用get方法
	 */
	@ApiOperation(value = "商品信息", notes = "获取对应商品信息")
	@GetMapping("/getGoods/{pk_goodsid}")
	public Goods getGoodsById(
			@ApiParam(name = "pk_goodsid", value = "商品id", required = true) @PathVariable("pk_goodsid") int pk_goodsid) {
		Goods goods = shopService.getGoodsById(pk_goodsid);
		return goods;
	}

}
