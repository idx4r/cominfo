package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;


@ApiModel(value="Apply",description="申请对象")
@SuppressWarnings("serial")
public class Apply implements Serializable {
	private Integer pk_applyid;
	private String proContent;
	private String location;
	private String tips;
	private Integer applyPoint;
	private Integer applyUserid;
	private Users applyUser;
	private String applyTime;
	private String applyAddress;
	private Integer applyState;
	
	public int getPk_applyid() {
		return pk_applyid;
	}
	public void setPk_applyid(Integer pk_applyid) {
		this.pk_applyid = pk_applyid;
	}
	public String getProContent() {
		return proContent;
	}
	public void setProContent(String proContent) {
		this.proContent = proContent;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTips() {
		return tips;
	}
	public void setTips(String tips) {
		this.tips = tips;
	}
	public int getApplyPoint() {
		return applyPoint;
	}
	public void setApplyPoint(Integer applyPoint) {
		this.applyPoint = applyPoint;
	}
	public int getApplyUserid() {
		return applyUserid;
	}
	public void setApplyUserid(Integer applyUserid) {
		this.applyUserid = applyUserid;
	}
	public Users getApplyUser() {
		return applyUser;
	}
	public void setApplyUser(Users applyUser) {
		this.applyUser = applyUser;
	}
	public String getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(String applyTime) {
		this.applyTime = applyTime;
	}
	public String getApplyAddress() {
		return applyAddress;
	}
	public void setApplyAddress(String applyAddress) {
		this.applyAddress = applyAddress;
	}
	public int getApplyState() {
		return applyState;
	}
	public void setApplyState(Integer applyState) {
		this.applyState = applyState;
	}
	
}
