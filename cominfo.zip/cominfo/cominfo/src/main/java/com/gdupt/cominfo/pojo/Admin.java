package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;

@ApiModel(value="Admin对象",description="管理员对象")
@SuppressWarnings("serial")
public class Admin implements Serializable{
	private Integer pk_adminid;
	private String adminPassword;
	private Integer adminTypeid;
	private String adminType;
	
	public int getPk_adminid() {
		return pk_adminid;
	}
	public void setPk_adminid(Integer pk_adminid) {
		this.pk_adminid = pk_adminid;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	public int getAdminTypeid() {
		return adminTypeid;
	}
	public void setAdminTypeid(Integer adminTypeid) {
		this.adminTypeid = adminTypeid;
	}
	public String getAdminType() {
		return adminType;
	}
	public void setAdminType(String adminType) {
		this.adminType = adminType;
	}
	
}
