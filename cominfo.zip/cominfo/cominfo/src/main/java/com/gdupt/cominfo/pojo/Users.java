package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;

@ApiModel(value="Users",description="用户对象")
@SuppressWarnings("serial")
public class Users implements Serializable {
	private Integer pk_userid;
	private String userName;
	private Integer userTypeid;
	private String userKind;
	private String password;
	private String gender;
	private String school;
	private String number;
	private String mailbox;
	private String address;
	private Integer point;
	private String openid;
	private Integer userState;
	private String avatarUrl;
	public Integer getPk_userid() {
		return pk_userid;
	}
	public void setPk_userid(Integer pk_userid) {
		this.pk_userid = pk_userid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getUserTypeid() {
		return userTypeid;
	}
	public void setUserTypeid(Integer userTypeid) {
		this.userTypeid = userTypeid;
	}
	public String getUserKind() {
		return userKind;
	}
	public void setUserKind(String userKind) {
		this.userKind = userKind;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getMailbox() {
		return mailbox;
	}
	public void setMailbox(String mailbox) {
		this.mailbox = mailbox;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getPoint() {
		return point;
	}
	public void setPoint(Integer point) {
		this.point = point;
	}
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public Integer getUserState() {
		return userState;
	}
	public void setUserState(Integer userState) {
		this.userState = userState;
	}
	public String getAvatarUrl() {
		return avatarUrl;
	}
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	

	
}
