package com.gdupt.cominfo.pojo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Orders implements Serializable {
	private Integer pk_orderid;
	private Integer orderUserid;
	private Integer goodsid;
	private Integer receiverid;
	private String orderTime;
	private Integer orderState;
	public Integer getPk_orderid() {
		return pk_orderid;
	}
	public void setPk_orderid(Integer pk_orderid) {
		this.pk_orderid = pk_orderid;
	}
	public Integer getOrderUserid() {
		return orderUserid;
	}
	public void setOrderUserid(Integer orderUserid) {
		this.orderUserid = orderUserid;
	}
	public Integer getGoodsid() {
		return goodsid;
	}
	public void setGoodsid(Integer goodsid) {
		this.goodsid = goodsid;
	}
	public Integer getReceiverid() {
		return receiverid;
	}
	public void setReceiverid(Integer receiverid) {
		this.receiverid = receiverid;
	}
	public String getOrderTime() {
		return orderTime;
	}
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}
	public Integer getOrderState() {
		return orderState;
	}
	public void setOrderState(Integer orderState) {
		this.orderState = orderState;
	}
	

	
	
}
