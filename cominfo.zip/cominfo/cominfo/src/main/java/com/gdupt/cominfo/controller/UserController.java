package com.gdupt.cominfo.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gdupt.cominfo.pojo.Apply;
import com.gdupt.cominfo.pojo.Collect;
import com.gdupt.cominfo.pojo.Data;
import com.gdupt.cominfo.pojo.Podcast;
import com.gdupt.cominfo.pojo.PodcastReply;
import com.gdupt.cominfo.pojo.Point;
import com.gdupt.cominfo.pojo.Question;
import com.gdupt.cominfo.pojo.Receive;
import com.gdupt.cominfo.pojo.Resource;
import com.gdupt.cominfo.pojo.Users;
import com.gdupt.cominfo.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags = "个人用户平台")
@RestController
public class UserController {
	@Autowired
	private UserService userService;

	/**
	 * 查询所有用户信息，使用get方法
	 */
	@ApiOperation(value = "用户列表", notes = "获取所有用户信息", httpMethod = "GET")
	@GetMapping("/getUserList")
	public List<Users> getUserList() {
		List<Users> userList = userService.getUserList();
		return userList;
	}

	/**
	 * 按id查询用户信息 1、@GetMapping表示可以使用get方法请求该api
	 * 2、"/userInfo/{pk_userid}"表示请求路径为/userInfo/{pk_userid}的形式，其中{pk_userid}为占位符
	 * 3、@PathVariable("pk_userid")表示将占位符{pk_userid}的值传递给pk_userid
	 * 4、也就是说/userInfo/123请求的话，会将123传递给参数pk_userid
	 */
	@ApiOperation(value = "用户信息", notes = "获取对应id用户信息", httpMethod = "GET")
	@GetMapping("/getUser/{pk_userid}")
	public Users getUserById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		Users userInfo = userService.getUserById(pk_userid);
		return userInfo;
	}

	/**
	 * 新增用户信息（注册） 1、@PostMapping表示使用post方法
	 * 2、@RequestBody表示将请求中的json信息转换为User类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "用户注册", notes = "新增用户信息", httpMethod = "POST")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PostMapping("/register")
	public Integer addUserInfo(@ApiParam(name = "user", value = "用户信息", required = true) @RequestBody Users user) {
		Integer add = userService.addUserInfo(user);
		return add;
	}

	/**
	 * 修改用户信息（完善个人信息） 1、@PutMapping表示使用put方法
	 * 2、@RequestBody表示将请求中的json信息转换为User类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "用户修改", notes = "修改用户信息", httpMethod = "PUT")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PutMapping("/editUser")
	public Integer editUserInfo(@ApiParam(name = "user", value = "用户信息", required = true) @RequestBody Users user) {
		// 修改指定id的商品信息
		Integer edit = userService.editUserInfo(user);
		return edit;
	}

	/**
	 * 删除用户信息 1、@DeleteMapping表示使用DELETE方法
	 * 2、@PathVariable("pk_userid")表示将占位符{pk_userid}的值传递给pk_userid
	 */
	@ApiOperation(value = "删除用户", notes = "删除用户信息", httpMethod = "DELETE")
	@DeleteMapping("/removeUser/{pk_userid}")
	public Integer removeUserInfo(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		Integer remove = userService.removeUserInfo(pk_userid);
		return remove;
	}

	/**
	 * 获取用户未删除文章记录
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户文章", notes = "获取用户未删除文章记录", httpMethod = "GET")
	@GetMapping("/getUserPod/{pk_userid}")
	public List<Podcast> getUserPodcastById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Podcast> userPodcast = userService.getUserPodcastById(pk_userid);
		return userPodcast;
	}

	/**
	 * 删除用户文章 1、@DeleteMapping表示使用DELETE方法
	 * 2、@PathVariable("pk_podid")表示将占位符{pk_podid}的值传递给pk_podid
	 */
	@ApiOperation(value = "删除文章", notes = "删除对应id文章", httpMethod = "DELETE")
	@DeleteMapping("/removeUserPod/{pk_podid}")
	public Integer removeUserPodById(
			@ApiParam(name = "pk_podid", value = "文章id", required = true) @PathVariable("pk_podid") Integer pk_podid) {
		Integer remove = userService.removeUserPodById(pk_podid);
		return remove;
	}

	/**
	 * 获取用户已删除文章记录
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "文章回收站", notes = "获取用户已删除文章记录", httpMethod = "GET")
	@GetMapping("/getUserDelPod/{pk_userid}")
	public List<Podcast> getUserDelPodById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Podcast> userDelPod = userService.getUserDelPodById(pk_userid);
		return userDelPod;
	}

	/**
	 * 恢复用户文章 1、@PutMapping表示使用put方法
	 */
	@ApiOperation(value = "回收站文章恢复", notes = "恢复对应id文章", httpMethod = "PUT")
	@PutMapping("/editUserDelPod/{pk_podid}")
	public Integer editUserDelPodById(
			@ApiParam(name = "pk_podid", value = "文章id", required = true) @PathVariable("pk_podid") Integer pk_podid) {
		Integer resume = userService.editUserDelPodById(pk_podid);
		return resume;
	}

	/**
	 * 获取用户未删除问题记录
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户问题", notes = "获取用户未删除问题记录", httpMethod = "GET")
	@GetMapping("/getUserQues/{pk_userid}")
	public List<Question> getUserQuestionById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Question> userQuestion = userService.getUserQuestionById(pk_userid);
		return userQuestion;
	}

	/**
	 * 删除用户问题 1、@DeleteMapping表示使用DELETE方法
	 * 2、@PathVariable("pk_quesid")表示将占位符{pk_quesid}的值传递给pk_quesid
	 */
	@ApiOperation(value = "删除问题", notes = "删除对应id问题", httpMethod = "DELETE")
	@DeleteMapping("/removeUserQues/{pk_quesid}")
	public Integer removeUserQuesById(
			@ApiParam(name = "pk_quesid", value = "问题id", required = true) @PathVariable("pk_quesid") Integer pk_quesid) {
		Integer remove = userService.removeUserQuesById(pk_quesid);
		return remove;
	}

	/**
	 * 获取用户已删除问题记录
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "问题回收站", notes = "获取用户已删除问题记录", httpMethod = "GET")
	@GetMapping("/getUserDelQues/{pk_userid}")
	public List<Question> getUserDelQuesById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Question> userQuestion = userService.getUserQuestionById(pk_userid);
		return userQuestion;
	}

	/**
	 * 恢复用户问题 1、@PutMapping表示使用put方法
	 */
	@ApiOperation(value = "回收站问题恢复", notes = "恢复对应id问题", httpMethod = "PUT")
	@PutMapping("/editUserDelQues/{pk_quesid}")
	public Integer editUserDelQuesById(
			@ApiParam(name = "pk_quesid", value = "文章id", required = true) @PathVariable("pk_podid") Integer pk_quesid) {
		Integer resume = userService.editUserDelQuesById(pk_quesid);
		return resume;
	}

	/**
	 * 检测用户名及密码（登录）
	 * 
	 * @param userName 用户名
	 * @param password 用户密码
	 * @return
	 */
	@ApiOperation(value = "用户登录", notes = "检测用户名及密码是否正确", httpMethod = "GET")
	@GetMapping("/login/{userName}/{password}")
	public Users checkUserAndPwd(
			@ApiParam(name = "userName", value = "用户名", required = true) @PathVariable("userName") String userName,
			@ApiParam(name = "password", value = "用户密码", required = true) @PathVariable("password") String password) {
		Users users = userService.checkUserAndPwd(userName, password);
		if (users == null) {
			return users;
		}
		return users;
	}

	/**
	 * 检测用户名重复（注册通过前检测）
	 * 
	 * @param userName 用户名
	 * @return
	 */
	@ApiOperation(value = "检测用户名重复", notes = "注册前检测用户名是否注册", httpMethod = "GET")
	@GetMapping("/checkUserExist/{userName}")
	public Integer checkUserIsExist(
			@ApiParam(name = "userName", value = "用户名", required = true) @PathVariable("userName") String userName) {
		Users users = userService.checkUserIsExist(userName);
		if (users == null) { // 无重复用户名
			return 1;
		}
		return 0;
	}

	/**
	 * 检测该用户的密码是否一致
	 * 
	 * @param pk_userid 用户id
	 * @param password  用户密码
	 * @return
	 */
	@ApiOperation(value = "检测密码一致", notes = "修改密码前确认密码", httpMethod = "GET")
	@GetMapping("/checkPasswordRight/{pk_userid}/{password}")
	public Integer checkPasswordIsRight(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid,
			@ApiParam(name = "password", value = "用户密码", required = true) @PathVariable("password") String password) {
		Users users = userService.checkPasswordIsRight(pk_userid, password);
		if (users == null) { // 确认密码错误
			return 0;
		}
		return 1;
	}

	/**
	 * 修改用户密码
	 * 
	 * @param pk_userid 用户id
	 * @param password  用户密码
	 * @return
	 */
	@ApiOperation(value = "修改密码", notes = "修改用户密码", httpMethod = "PUT")
	@PutMapping("/editUserPassword/{pk_userid}/{password}")
	public Integer editUserPasswordById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid,
			@ApiParam(name = "password", value = "用户密码", required = true) @PathVariable("password") String password) {
		Integer resume = userService.editUserPasswordById(pk_userid, password);
		return resume;
	}

	/**
	 * 获取用户回复列表，使用get方法
	 */
	@ApiOperation(value = "回复列表", notes = "获取用户回复列表", httpMethod = "GET")
	@GetMapping("/getUserPodReply/{prUseredid}")
	public List<PodcastReply> getUserPodReplyById(
			@ApiParam(name = "prUseredid", value = "被用户id", required = true) @PathVariable("prUseredid") Integer prUseredid) {
		List<PodcastReply> userPodReply = userService.getUserPodReplyById(prUseredid);
		return userPodReply;
	}

	/**
	 * 发布文章 1、@PostMapping表示使用post方法
	 * 2、@RequestBody表示将请求中的json信息转换为Podcast类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "发布文章", notes = "向社区发布文章", httpMethod = "POST")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PostMapping("/addPodcast/{podType}/{podContent}/{podUserid}/{podTitle}")
	public Integer addPodcast(
			@ApiParam(name = "podType", value = "文章类型", required = true) @PathVariable("podType") String podType,
			@ApiParam(name = "podContent", value = "文章内容", required = true) @PathVariable("podContent") String podContent,
			@ApiParam(name = "podUserid", value = "用户id", required = true) @PathVariable("podUserid") Integer podUserid,
			@ApiParam(name = "podTitle", value = "文章标题", required = true) @PathVariable("podTitle") String podTitle) {
		LocalDate date = LocalDate.now(); // get the current date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		Podcast podcast = new Podcast();
		podcast.setPodType(podType);
		podcast.setPodContent(podContent);
		podcast.setPodTime(date.format(formatter));
		podcast.setPodUserid(podUserid);
		podcast.setPodTitle(podTitle);
		Integer add = userService.addPodcast(podcast);
		return add;
	}

	/**
	 * 提出问题 1、@PostMapping表示使用post方法
	 * 2、@RequestBody表示将请求中的json信息转换为Podcast类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "提出问题", notes = "向社区提出问题", httpMethod = "POST")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PostMapping("/addQuestion/{quesType}/{quesContent}/{quesUserid}/{quesTitle}/{quesPoInteger}/{inviteUserid}")
	public Integer addQuestion(
			@ApiParam(name = "quesType", value = "问题类型", required = true) @PathVariable("quesType") String quesType,
			@ApiParam(name = "quesContent", value = "问题内容", required = true) @PathVariable("quesContent") String quesContent,
			@ApiParam(name = "quesUserid", value = "用户id", required = true) @PathVariable("quesUserid") Integer quesUserid,
			@ApiParam(name = "quesTitle", value = "问题标题", required = true) @PathVariable("quesTitle") String quesTitle,
			@ApiParam(name = "quesPoint", value = "问题积分", required = true) @PathVariable("quesPoint") Integer quesPoint,
			@ApiParam(name = "inviteUserid", value = "受邀用户id", required = true) @PathVariable("inviteUserid") Integer inviteUserid) {
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		Question question = new Question();
		question.setQuesType(quesType);
		question.setQuesContent(quesContent);
		question.setQuesUserid(quesUserid);
		question.setQuesTitle(quesTitle);
		question.setQuesPoint(quesPoint);
		question.setInviteUserid(inviteUserid);
		question.setQuesTime(date.format(formatter));
		Integer add = userService.addQuestion(question);
		return add;
	}

	/**
	 * 获取用户发布资源，使用get方法
	 */
	@ApiOperation(value = "用户资源", notes = "获取用户发布资源", httpMethod = "GET")
	@GetMapping("/getUserResource/{resourceUserid}")
	public List<Resource> getUserResourceById(
			@ApiParam(name = "resourceUserid", value = "用户id", required = true) @PathVariable("resourceUserid") Integer resourceUserid) {
		List<Resource> userResource = userService.getUserResourceById(resourceUserid);
		return userResource;
	}

	/**
	 * 获取用户受邀列表，使用get方法
	 */
	@ApiOperation(value = "用户受邀", notes = "获取用户受邀信息", httpMethod = "GET")
	@GetMapping("/getUserInvited/{inviteUserid}")
	public List<Question> getUserInvitedById(
			@ApiParam(name = "inviteUserid", value = "用户id", required = true) @PathVariable("inviteUserid") Integer inviteUserid) {
		List<Question> userInvited = userService.getUserInvitedById(inviteUserid);
		return userInvited;
	}
	
	/**
	 * 提出问题 1、@PostMapping表示使用post方法
	 * 2、@RequestBody表示将请求中的json信息转换为Apply类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "申请上门", notes = "请求实地帮助", httpMethod = "POST")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PostMapping("/addApply/{proContent}/{location}/{tips}/{applyPoint}/{applyUserid}/{applyAddress}")
	public Integer addApply(
			@ApiParam(name = "proContent", value = "问题讲述", required = true) @PathVariable("proContent") String proContent,
			@ApiParam(name = "location", value = "所处院校", required = true) @PathVariable("location") String location,
			@ApiParam(name = "tips", value = "温馨提示", required = true) @PathVariable("tips") String tips,
			@ApiParam(name = "applyPoint", value = "申请积分", required = true) @PathVariable("applyPoint") Integer applyPoint,
			@ApiParam(name = "applyUserid", value = "用户id", required = true) @PathVariable("applyUserid") Integer applyUserid,
			@ApiParam(name = "applyAddress", value = "申请地点", required = true) @PathVariable("applyAddress") String applyAddress) {
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		Apply apply = new Apply();
		apply.setProContent(proContent);
		apply.setLocation(location);
		apply.setTips(tips);
		apply.setApplyPoint(applyPoint);
		apply.setApplyUserid(applyUserid);
		apply.setApplyAddress(applyAddress);
		apply.setApplyTime(date.format(formatter));
		Integer add = userService.addApply(apply);
		return add;
	}
	

	/**
	 * 删除资源信息 1、@DeleteMapping表示使用DELETE方法
	 * 2、@PathVariable("pk_resourceid")表示将占位符{pk_resourceid}的值传递给pk_resourceid
	 */
	@ApiOperation(value = "删除资源", notes = "删除对应资源信息")
	@DeleteMapping("/removeResource/{pk_resourceid}")
	public Integer removeResourceInfo(
			@ApiParam(name = "pk_resourceid", value = "资源id", required = true) @PathVariable("pk_resourceid") Integer pk_resourceid) {
		Integer remove = userService.removeResourceInfo(pk_resourceid);
		return remove;
	}
	
	/**
	 * 恢复用户资源 1、@PutMapping表示使用put方法
	 */
	@ApiOperation(value = "回收站资源恢复", notes = "恢复对应id资源", httpMethod = "PUT")
	@PutMapping("/editUserDelResource/{pk_resourceid}")
	public Integer editUserDelResourceById(
			@ApiParam(name = "pk_resourceid", value = "文章id", required = true) @PathVariable("pk_resourceid") Integer pk_resourceid) {
		Integer resume = userService.editUserDelResourceById(pk_resourceid);
		return resume;
	}

	/**
	 * 新增资源信息（上传资源） 1、@PostMapping表示使用post方法
	 * 2、@RequestBody表示将请求中的json信息转换为Resource类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "上传资源", notes = "新增资源信息")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PostMapping("/addResource/{resourceType}/{download}/{link}/{resourceUserid}/{resourceTitle}/{resourceContent}/{resourcePoint}")
	public Integer addResourceInfo(
			@ApiParam(name = "resourceType", value = "资源类型", required = true) @PathVariable("resourceType") String resourceType,
			@ApiParam(name = "download", value = "资源下载量", required = true) @PathVariable("download") Integer download,
			@ApiParam(name = "link", value = "资源链接", required = true) @PathVariable("link") String link,
			@ApiParam(name = "resourceUserid", value = "用户id", required = true) @PathVariable("resourceUserid") Integer resourceUserid,
			@ApiParam(name = "resourceTitle", value = "资源标题", required = true) @PathVariable("resourceTitle") String resourceTitle,
			@ApiParam(name = "resourceContent", value = "资源内容", required = true) @PathVariable("resourceContent") String resourceContent,
			@ApiParam(name = "resourcePoint", value = "资源积分", required = true) @PathVariable("resourcePoint") Integer resourcePoint) {
		LocalDate date = LocalDate.now(); // get the current date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		Resource resource = new Resource();
		resource.setResourceType(resourceType);
		resource.setDownload(download);
		resource.setLink(link);
		resource.setResourceUserid(resourceUserid);
		resource.setResourceTitle(resourceTitle);
		resource.setResourceContent(resourceContent);
		resource.setResourcePoint(resourcePoint);
		resource.setResourceTime(date.format(formatter));
		Integer add = userService.addResourceInfo(resource);
		return add;
	}
	
	/**
	 * 获取用户文章数据
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户文章数据", notes = "获取用户文章数据", httpMethod = "GET")
	@GetMapping("/getUserPodData/{pk_userid}")
	public Data getUserPodDataById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		Data userPodData = userService.getUserPodDataById(pk_userid);
		return userPodData;
	}

	/**
	 * 获取用户问题数据
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户问题数据", notes = "获取用户问题数据", httpMethod = "GET")
	@GetMapping("/getUserQuesData/{pk_userid}")
	public Data getUserQuesDataById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		Data userQuesData = userService.getUserQuesDataById(pk_userid);
		return userQuesData;
	}
	
	/**
	 * 获取用户资源数据
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户资源数据", notes = "获取用户资源数据", httpMethod = "GET")
	@GetMapping("/getUserResourceData/{pk_userid}")
	public Data getUserResourceDataById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		Data userResourceData = userService.getUserResourceDataById(pk_userid);
		return userResourceData;
	}
	
	/**
	 * 用户取消文章收藏 1、@DeleteMapping表示使用put方法
	 */
	@Transactional(rollbackFor=Exception.class)	//事务
	@ApiOperation(value = "文章取消收藏", notes = "取消对应id收藏文章", httpMethod = "DELETE")
	@DeleteMapping("/removeUserPodCollect/{collectContentid}/{collectUserid}")
	public Integer removeUserPodCollect(
			@ApiParam(name = "collectContentid", value = "文章id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTypeid(1);
		Integer cancel = 0;
		if(userService.checkUserCollectIsExist(collect) != null) {
			cancel = userService.removePodCollectNum(collectContentid);	//减少文章收藏数
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());	//获取取消的收藏			
			cancel = userService.removeCollect(collect);
		}
		return cancel;
	}
	
	/**
	 * 用户取消问题收藏 1、@DeleteMapping表示使用put方法
	 */
	@Transactional(rollbackFor=Exception.class)	//事务
	@ApiOperation(value = "问题取消收藏", notes = "取消对应id收藏问题", httpMethod = "DELETE")
	@DeleteMapping("/removeUserQuesCollect/{collectContentid}/{collectUserid}")
	public Integer removeUserQuesCollect(
			@ApiParam(name = "collectContentid", value = "文章id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTypeid(2);
		Integer cancel = 0;
		if(userService.checkUserCollectIsExist(collect) != null) {
			cancel = userService.removeQuesCollectNum(collectContentid);	//减少文章收藏数
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());	//获取取消的收藏			
			cancel = userService.removeCollect(collect);
		}
		return cancel;
	}
	
	/**
	 * 用户取消资源收藏 1、@DeleteMapping表示使用put方法
	 */
	@Transactional(rollbackFor=Exception.class)	//事务
	@ApiOperation(value = "资源取消收藏", notes = "取消对应id收藏资源", httpMethod = "DELETE")
	@DeleteMapping("/removeUserResourceCollect/{collectContentid}/{collectUserid}")
	public Integer removeUserResourceCollect(
			@ApiParam(name = "collectContentid", value = "文章id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTypeid(3);
		Integer cancel = 0;
		if(userService.checkUserCollectIsExist(collect) != null) {
			cancel = userService.removeResourceCollectNum(collectContentid);	//减少文章收藏数
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());	//获取取消的收藏			
			cancel = userService.removeCollect(collect);
		}
		return cancel;
	}
	
	/**
	 * 用户取消商品收藏 1、@DeleteMapping表示使用put方法
	 */
	@Transactional(rollbackFor=Exception.class)	//事务
	@ApiOperation(value = "商品取消收藏", notes = "取消对应id收藏商品", httpMethod = "DELETE")
	@DeleteMapping("/removeUserGoodsCollect/{collectContentid}/{collectUserid}")
	public Integer removeUserGoodsCollect(
			@ApiParam(name = "collectContentid", value = "文章id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTypeid(4);
		Integer cancel = 0;
		if(userService.checkUserCollectIsExist(collect) != null) {
			cancel = userService.removeGoodsCollectNum(collectContentid);	//减少文章收藏数
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());	//获取取消的收藏			
			cancel = userService.removeCollect(collect);
		}
		return cancel;
	}
	
	/**
	 * 用户添加文章收藏 1、@PostMapping表示使用put方法
	 */
	@Transactional(rollbackFor=Exception.class)	//事务
	@ApiOperation(value = "文章添加收藏", notes = "对应id收藏文章", httpMethod = "POST")
	@PostMapping("/addUserPodCollect/{collectContentid}/{collectUserid}")
	public Integer addUserPodCollect(
			@ApiParam(name = "collectContentid", value = "文章id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		LocalDate date = LocalDate.now(); // get the current date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectTypeid(1);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTime(date.format(formatter));
		Integer add = userService.addPodCollectNum(collectContentid);	//增加文章收藏数
		if(userService.checkUserCollectIsExist(collect)==null) {	//检测用户是否进行过收藏
			add = userService.addCollect(collect);	//新增文章收藏			
		}else {	//用户已收藏过该文章
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());
			add = userService.addRecoverCollect(collect);	//恢复文章收藏
		}
		return add;
	}
	
	/**
	 * 用户添加问题收藏 1、@PostMapping表示使用put方法
	 */
	@Transactional(rollbackFor=Exception.class)	//事务
	@ApiOperation(value = "问题添加收藏", notes = "对应id收藏问题", httpMethod = "POST")
	@PostMapping("/addUserQuesCollect/{collectContentid}/{collectUserid}")
	public Integer addUserQuesCollect(
			@ApiParam(name = "collectContentid", value = "问题id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		LocalDate date = LocalDate.now(); // get the current date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectTypeid(2);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTime(date.format(formatter));
		Integer add = userService.addQuesCollectNum(collectContentid);	//增加问题收藏数
		if(userService.checkUserCollectIsExist(collect)==null) {	//检测用户是否进行过收藏
			add = userService.addCollect(collect);	//新增问题收藏			
		}else {	//用户已收藏过该问题
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());
			add = userService.addRecoverCollect(collect);	//恢复问题收藏
		}
		return add;
	}
	
	/**
	 * 用户添加资源收藏 1、@PostMapping表示使用put方法
	 */
	@ApiOperation(value = "资源添加收藏", notes = "对应id收藏资源", httpMethod = "POST")
	@PostMapping("/addUserResourceCollect/{collectContentid}/{collectUserid}")
	public Integer addUserResourceCollect(
			@ApiParam(name = "collectContentid", value = "资源id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		LocalDate date = LocalDate.now(); // get the current date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectTypeid(3);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTime(date.format(formatter));
		Integer add = userService.addResourceCollectNum(collectContentid);	//增加资源收藏数
		if(userService.checkUserCollectIsExist(collect)==null) {	//检测用户是否进行过收藏
			add = userService.addCollect(collect);	//新增资源收藏			
		}else {	//用户已收藏过该资源
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());
			add = userService.addRecoverCollect(collect);	//恢复资源收藏
		}
		return add;
	}
	
	/**
	 * 用户添加商品收藏 1、@PostMapping表示使用put方法
	 */
	@ApiOperation(value = "商品添加收藏", notes = "对应id收藏商品", httpMethod = "POST")
	@PostMapping("/addUserGoodsCollect/{collectContentid}/{collectUserid}")
	public Integer addUserGoodsCollect(
			@ApiParam(name = "collectContentid", value = "商品id", required = true) @PathVariable("collectContentid") Integer collectContentid,
			@ApiParam(name = "collectUserid", value = "用户id", required = true) @PathVariable("collectUserid") Integer collectUserid) {
		LocalDate date = LocalDate.now(); // get the current date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
		Collect collect = new Collect();
		collect.setCollectUserid(collectUserid);
		collect.setCollectTypeid(4);
		collect.setCollectContentid(collectContentid);
		collect.setCollectTime(date.format(formatter));
		Integer add = userService.addGoodsCollectNum(collectContentid);	//增加商品收藏数
		if(userService.checkUserCollectIsExist(collect)==null) {	//检测用户是否进行过收藏
			add = userService.addCollect(collect);	//新增商品收藏			
		}else {	//用户已收藏过该商品
			collect.setPk_collectid(userService.checkUserCollectIsExist(collect).getPk_collectid());
			add = userService.addRecoverCollect(collect);	//恢复商品收藏
		}
		return add;
	}
	
	/**
	 * 获取用户文章收藏信息
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户文章收藏", notes = "获取用户文章收藏信息", httpMethod = "GET")
	@GetMapping("/getUserPodCollect/{pk_userid}")
	public List<Collect> getUserPodCollectById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Collect> userPodCollect = userService.getUserCollectById(pk_userid,1);
		return userPodCollect;
	}
	
	/**
	 * 获取用户问题收藏信息
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户问题收藏", notes = "获取用户问题收藏信息", httpMethod = "GET")
	@GetMapping("/getUserQuesCollect/{pk_userid}")
	public List<Collect> getUserQuesCollectById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Collect> userPodCollect = userService.getUserCollectById(pk_userid,2);
		return userPodCollect;
	}
	
	/**
	 * 获取用户资源收藏信息
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户资源收藏", notes = "获取用户资源收藏信息", httpMethod = "GET")
	@GetMapping("/getUserResourceCollect/{pk_userid}")
	public List<Collect> getUserResourceCollectById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Collect> userPodCollect = userService.getUserCollectById(pk_userid,3);
		return userPodCollect;
	}
	
	/**
	 * 获取用户商品收藏信息
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户商品收藏", notes = "获取用户商品收藏信息", httpMethod = "GET")
	@GetMapping("/getUserGoodsCollect/{pk_userid}")
	public List<Collect> getUserGoodsCollectById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Collect> userPodCollect = userService.getUserCollectById(pk_userid,4);
		return userPodCollect;
	}
		
	/**
	 * 获取用户积分记录
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "积分记录", notes = "获取用户积分记录", httpMethod = "GET")
	@GetMapping("/getUserPoint/{pk_userid}")
	public List<Point> getUserPointById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Point> userPoint = userService.getUserPointById(pk_userid);
		return userPoint;
	}
	
	/**
	 * 获取用户邮寄列表
	 * 
	 * @param pk_userid 用户id
	 */
	@ApiOperation(value = "用户邮寄", notes = "获取用户邮寄列表", httpMethod = "GET")
	@GetMapping("/getUserReceive/{pk_userid}")
	public List<Receive> getUserReceiveById(
			@ApiParam(name = "pk_userid", value = "用户id", required = true) @PathVariable("pk_userid") Integer pk_userid) {
		List<Receive> userReceive = userService.getUserReceiveById(pk_userid);
		return userReceive;
	}
	
	/**
	 * 获取邮寄信息
	 * 
	 * @param pk_receiveid 邮寄id
	 */
	@ApiOperation(value = "邮寄卡片", notes = "获取邮寄信息", httpMethod = "GET")
	@GetMapping("/getReceive/{pk_receiveid}")
	public Receive getReceiveById(
			@ApiParam(name = "pk_receiveid", value = "邮寄id", required = true) @PathVariable("pk_receiveid") Integer pk_receiveid) {
		Receive receive = userService.getReceiveById(pk_receiveid);
		return receive;
	}
	
	/**
	 * 新增邮寄卡片 1、@PostMapping表示使用post方法
	 * 2、@RequestBody表示将请求中的json信息转换为Receive类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "添加邮寄卡片", notes = "新增邮寄卡片", httpMethod = "POST")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PostMapping("/addReceive")
	public Integer addReceiveInfo(@ApiParam(name = "receive", value = "邮寄信息", required = true) @RequestBody Receive receive) {
		Integer add = userService.addReceiveInfo(receive);
		return add;
	}
	
	/**
	 * 修改邮寄卡片 1、@PutMapping表示使用put方法
	 * 2、@RequestBody表示将请求中的json信息转换为Receive类型的对象信息，该转换也是由SpringMVC自动完成的
	 */
	@ApiOperation(value = "修改邮寄卡片", notes = "修改邮寄卡片", httpMethod = "PUT")
	@ApiResponses({ @ApiResponse(code = 400, message = "请求参数没填好"),
			@ApiResponse(code = 404, message = "请求路径没有或页面跳转路径不对") })
	@PutMapping("/editReceive")
	public Integer editReceiveInfo(@ApiParam(name = "receive", value = "邮寄信息", required = true) @RequestBody Receive receive) {
		// 修改指定id的商品信息
		Integer edit = userService.editReceiveInfo(receive);
		return edit;
	}
	
	/**
	 * 删除邮寄卡片 1、@DeleteMapping表示使用DELETE方法
	 * 2、@PathVariable("pk_receiveid")表示将占位符{pk_receiveid}的值传递给pk_receiveid
	 */
	@ApiOperation(value = "删除邮寄卡片", notes = "删除邮寄卡片", httpMethod = "DELETE")
	@DeleteMapping("/removeReceive/{pk_receiveid}")
	public Integer removeReceiveInfo(
			@ApiParam(name = "pk_receiveid", value = "邮寄id", required = true) @PathVariable("pk_receiveid") Integer pk_receiveid) {
		Integer remove = userService.removeReceiveInfo(pk_receiveid);
		return remove;
	}
	
	@ApiOperation(value = "手机验证码", notes = "获取绑定手机验证码", httpMethod = "GET")
	@GetMapping("/getPhonemsg/{number}")
	public String getPhonemsg(
			@ApiParam(name = "number", value = "绑定手机号", required = true) @PathVariable("number") Integer number) {
		return "true";
	}

}
