package com.gdupt.cominfo.pojo;

public class Collect {
	private Integer pk_collectid;
	private Integer collectUserid;
	private Integer collectTypeid;
	private String collectKind;
	private String collectTime;
	private Integer collectContentid;
	
	public Integer getPk_collectid() {
		return pk_collectid;
	}
	public void setPk_collectid(Integer pk_collectid) {
		this.pk_collectid = pk_collectid;
	}
	public Integer getCollectUserid() {
		return collectUserid;
	}
	public void setCollectUserid(Integer collectUserid) {
		this.collectUserid = collectUserid;
	}
	public Integer getCollectTypeid() {
		return collectTypeid;
	}
	public void setCollectTypeid(Integer collectTypeid) {
		this.collectTypeid = collectTypeid;
	}
	public String getCollectKind() {
		return collectKind;
	}
	public void setCollectKind(String collectKind) {
		this.collectKind = collectKind;
	}
	public String getCollectTime() {
		return collectTime;
	}
	public void setCollectTime(String collectTime) {
		this.collectTime = collectTime;
	}
	public Integer getCollectContentid() {
		return collectContentid;
	}
	public void setCollectContentid(Integer collectContentid) {
		this.collectContentid = collectContentid;
	}
	
	
}
