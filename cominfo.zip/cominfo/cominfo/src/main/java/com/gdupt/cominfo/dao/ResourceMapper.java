package com.gdupt.cominfo.dao;

import java.util.List;

import com.gdupt.cominfo.pojo.Resource;

public interface ResourceMapper {
	
	public List<Resource> getResourceList();
	
	public List<Resource> getResourceListByDownload();
	
	public List<Resource> getResourceListByTime();

	public Resource getResourceById(int pk_resourceid);
	
	public List<Resource> getResourceByTitle(String resourceTitle);
	
	public List<Resource> getResourceByType(String resourceType);
	
}
