package com.gdupt.cominfo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdupt.cominfo.dao.ResourceMapper;
import com.gdupt.cominfo.pojo.Resource;

@Service
public class ResourceService {

	@Autowired
	private ResourceMapper resourceMapper;
	
	public List<Resource> getResourceList() {
		return resourceMapper.getResourceList();
	}
	
	public List<Resource> getResourceListByDownload() {
		return resourceMapper.getResourceListByDownload();
	}
	
	public List<Resource> getResourceListByTime(){
		return resourceMapper.getResourceListByTime();
	}
	
	public Resource getResourceById(int pk_resourceid) {
		return resourceMapper.getResourceById(pk_resourceid);
	}
	
	public List<Resource> getResourceByTitle(String resourceTitle){
		return resourceMapper.getResourceByTitle(resourceTitle);
	}

	public List<Resource> getResourceByType(String resourceType){
		return resourceMapper.getResourceByType(resourceType);
	}
	
}
