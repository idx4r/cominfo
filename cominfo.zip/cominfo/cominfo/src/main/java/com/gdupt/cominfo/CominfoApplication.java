package com.gdupt.cominfo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages= {"com.gdupt.cominfo.dao"})
public class CominfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CominfoApplication.class, args);
	}

}
