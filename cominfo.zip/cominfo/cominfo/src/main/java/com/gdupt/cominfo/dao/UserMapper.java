package com.gdupt.cominfo.dao;

import java.util.List;

import com.gdupt.cominfo.pojo.Apply;
import com.gdupt.cominfo.pojo.Collect;
import com.gdupt.cominfo.pojo.Data;
import com.gdupt.cominfo.pojo.Podcast;
import com.gdupt.cominfo.pojo.PodcastReply;
import com.gdupt.cominfo.pojo.Point;
import com.gdupt.cominfo.pojo.Question;
import com.gdupt.cominfo.pojo.Receive;
import com.gdupt.cominfo.pojo.Resource;
import com.gdupt.cominfo.pojo.Users;

public interface UserMapper {

	public List<Users> getUserList();

	public Users getUserById(Integer pk_userid);

	public Integer addUserInfo(Users user);

	public Integer editUserInfo(Users user);

	public Integer removeUserInfo(Integer pk_userid);

	public List<Podcast> getUserPodcastById(Integer pk_userid);

	public Integer removeUserPodById(Integer pk_podid);

	public List<Podcast> getUserDelPodById(Integer pk_userid);

	public Integer editUserDelPodById(Integer pk_podid);

	public List<Question> getUserQuestionById(Integer pk_userid);

	public Integer removeUserQuesById(Integer pk_quesid);

	public List<Question> getUserDelQuesById(Integer pk_userid);

	public int editUserDelQuesById(Integer pk_quesid);

	public Users checkUserAndPwd(String userName, String password);

	public Users checkUserIsExist(String userName);

	public Users checkPasswordIsRight(Integer pk_userid, String password);

	public Integer editUserPasswordById(Integer pk_userid, String password);

	public List<PodcastReply> getUserPodReplyById(Integer prUseredid);

	public Integer addPodcast(Podcast podcast);

	public Integer addQuestion(Question question);

	public List<Resource> getUserResourceById(Integer resourceUserid);
	
	public List<Question> getUserInvitedById(Integer inviteUserid);
	
	public Integer addApply(Apply apply);
	
	public Integer removeResourceInfo(Integer pk_resourceid);
	
	public Integer editUserDelResourceById(Integer pk_resourceid);
	
	public Integer addResourceInfo(Resource resource);
	
	public Data getUserPodDataById(Integer pk_userid);
	
	public Data getUserQuesDataById(Integer pk_userid);
	
	public Data getUserResourceDataById(Integer pk_userid);
	
	public Integer removePodCollectNum(Integer pk_podid);
	
	public Integer removeQuesCollectNum(Integer pk_quesid);
	
	public Integer removeResourceCollectNum(Integer pk_resourceid);
	
	public Integer removeGoodsCollectNum(Integer pk_goodsid);
	
	public Integer removeCollect(Collect collect);

	public Integer addPodCollectNum(Integer pk_podid);
	
	public Integer addQuesCollectNum(Integer pk_quesid);
	
	public Integer addResourceCollectNum(Integer pk_resourceid);
	
	public Integer addGoodsCollectNum(Integer pk_goodsid);
	
	public Integer addCollect(Collect collect);
	
	public Integer addRecoverCollect(Collect collect);
	
	public Collect checkUserCollectIsExist(Collect collect);
	
	public List<Collect> getUserCollectById(Integer pk_userid,Integer collectTypeid);
	
	public List<Point> getUserPointById(Integer pk_userid);
	
	public List<Receive> getUserReceiveById(Integer pk_userid);
	
	public Receive getReceiveById(Integer pk_receiveid);
	
	public int addReceiveInfo(Receive receive);
	
	public int editReceiveInfo(Receive receive);
	
	public int removeReceiveInfo(Integer pk_receiveid);
	
}
