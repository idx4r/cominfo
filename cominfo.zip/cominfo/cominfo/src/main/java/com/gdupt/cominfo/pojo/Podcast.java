package com.gdupt.cominfo.pojo;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;


@ApiModel(value="Podcast",description="文章对象")
@SuppressWarnings("serial")
public class Podcast implements Serializable{
	private Integer pk_podid;
	private String podType;
	private String podContent;
	private String podTime;
	private Integer podUserid;
	private String podUserName;
	private Integer podView;
	private Integer podForward;
	private Integer podLike;
	private Integer podComment;	//博文评论数
	private Integer podCollect;
	private List<PodcastComment> podCommentList;
	private Integer podState;
	private String podTitle;
	private List<Podcast> relatedPodcast;
	public Integer getPk_podid() {
		return pk_podid;
	}
	public void setPk_podid(Integer pk_podid) {
		this.pk_podid = pk_podid;
	}
	public String getPodType() {
		return podType;
	}
	public void setPodType(String podType) {
		this.podType = podType;
	}
	public String getPodContent() {
		return podContent;
	}
	public void setPodContent(String podContent) {
		this.podContent = podContent;
	}
	public String getPodTime() {
		return podTime;
	}
	public void setPodTime(String podTime) {
		this.podTime = podTime;
	}
	public Integer getPodUserid() {
		return podUserid;
	}
	public void setPodUserid(Integer podUserid) {
		this.podUserid = podUserid;
	}
	public String getPodUserName() {
		return podUserName;
	}
	public void setPodUserName(String podUserName) {
		this.podUserName = podUserName;
	}
	public Integer getPodView() {
		return podView;
	}
	public void setPodView(Integer podView) {
		this.podView = podView;
	}
	public Integer getPodForward() {
		return podForward;
	}
	public void setPodForward(Integer podForward) {
		this.podForward = podForward;
	}
	public Integer getPodLike() {
		return podLike;
	}
	public void setPodLike(Integer podLike) {
		this.podLike = podLike;
	}
	public Integer getPodComment() {
		return podComment;
	}
	public void setPodComment(Integer podComment) {
		this.podComment = podComment;
	}
	public Integer getPodCollect() {
		return podCollect;
	}
	public void setPodCollect(Integer podCollect) {
		this.podCollect = podCollect;
	}
	public List<PodcastComment> getPodCommentList() {
		return podCommentList;
	}
	public void setPodCommentList(List<PodcastComment> podCommentList) {
		this.podCommentList = podCommentList;
	}
	public Integer getPodState() {
		return podState;
	}
	public void setPodState(Integer podState) {
		this.podState = podState;
	}
	public String getPodTitle() {
		return podTitle;
	}
	public void setPodTitle(String podTitle) {
		this.podTitle = podTitle;
	}
	public List<Podcast> getRelatedPodcast() {
		return relatedPodcast;
	}
	public void setRelatedPodcast(List<Podcast> relatedPodcast) {
		this.relatedPodcast = relatedPodcast;
	}
	


	
	
}
