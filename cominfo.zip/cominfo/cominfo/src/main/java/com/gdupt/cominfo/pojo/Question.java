package com.gdupt.cominfo.pojo;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;

@ApiModel(value="Question",description="问题对象")
@SuppressWarnings("serial")
public class Question implements Serializable {
	private Integer pk_quesid;
	private String quesType;
	private String quesContent;
	private String quesTitle;
	private Integer quesPoint;
	private String quesTime;
	private Integer quesUserid;
	private Users quesUser;
	private Integer inviteUserid;
	private Users inviteUser;
	private Integer quesState;
	private Integer quesView;
	private Integer quesComment;
	private Integer quesCollect;
	private List<QuestionComment> quesCommentList;
	private Integer quesLike;
	private Integer quesForward;
	public Integer getPk_quesid() {
		return pk_quesid;
	}
	public void setPk_quesid(Integer pk_quesid) {
		this.pk_quesid = pk_quesid;
	}
	public String getQuesType() {
		return quesType;
	}
	public void setQuesType(String quesType) {
		this.quesType = quesType;
	}
	public String getQuesContent() {
		return quesContent;
	}
	public void setQuesContent(String quesContent) {
		this.quesContent = quesContent;
	}
	public String getQuesTitle() {
		return quesTitle;
	}
	public void setQuesTitle(String quesTitle) {
		this.quesTitle = quesTitle;
	}
	public Integer getQuesPoint() {
		return quesPoint;
	}
	public void setQuesPoint(Integer quesPoint) {
		this.quesPoint = quesPoint;
	}
	public String getQuesTime() {
		return quesTime;
	}
	public void setQuesTime(String quesTime) {
		this.quesTime = quesTime;
	}
	public Integer getQuesUserid() {
		return quesUserid;
	}
	public void setQuesUserid(Integer quesUserid) {
		this.quesUserid = quesUserid;
	}
	public Users getQuesUser() {
		return quesUser;
	}
	public void setQuesUser(Users quesUser) {
		this.quesUser = quesUser;
	}
	public Integer getInviteUserid() {
		return inviteUserid;
	}
	public void setInviteUserid(Integer inviteUserid) {
		this.inviteUserid = inviteUserid;
	}
	public Users getInviteUser() {
		return inviteUser;
	}
	public void setInviteUser(Users inviteUser) {
		this.inviteUser = inviteUser;
	}
	public Integer getQuesState() {
		return quesState;
	}
	public void setQuesState(Integer quesState) {
		this.quesState = quesState;
	}
	public Integer getQuesView() {
		return quesView;
	}
	public void setQuesView(Integer quesView) {
		this.quesView = quesView;
	}
	public Integer getQuesComment() {
		return quesComment;
	}
	public void setQuesComment(Integer quesComment) {
		this.quesComment = quesComment;
	}
	public Integer getQuesCollect() {
		return quesCollect;
	}
	public void setQuesCollect(Integer quesCollect) {
		this.quesCollect = quesCollect;
	}
	public List<QuestionComment> getQuesCommentList() {
		return quesCommentList;
	}
	public void setQuesCommentList(List<QuestionComment> quesCommentList) {
		this.quesCommentList = quesCommentList;
	}
	public Integer getQuesLike() {
		return quesLike;
	}
	public void setQuesLike(Integer quesLike) {
		this.quesLike = quesLike;
	}
	public Integer getQuesForward() {
		return quesForward;
	}
	public void setQuesForward(Integer quesForward) {
		this.quesForward = quesForward;
	}
	


	
}
