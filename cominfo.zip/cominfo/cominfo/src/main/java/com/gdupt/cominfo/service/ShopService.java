package com.gdupt.cominfo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gdupt.cominfo.dao.ShopMapper;
import com.gdupt.cominfo.pojo.Goods;

@Service
public class ShopService {

	@Autowired
	private ShopMapper shopMapper;
	
	public List<Goods> getGoodsList() {
		return shopMapper.getGoodsList();
	}
	
	public Goods getGoodsById(Integer pk_goodsid) {
		return shopMapper.getGoodsById(pk_goodsid);
	}
}
