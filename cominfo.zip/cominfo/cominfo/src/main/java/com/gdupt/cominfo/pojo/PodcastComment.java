package com.gdupt.cominfo.pojo;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;

@ApiModel(value="PodcastComment",description="文章评论对象")
@SuppressWarnings("serial")
public class PodcastComment implements Serializable {
	private Integer pk_pcid;
	private Integer podid;
	private String pcTime;
	private String pcContent;
	private Integer pcUserid;
	private String pcUserName;
	private Integer pcLike;
	private Integer pcReply; //评论回复数
	private List<PodcastReply> pcReplyList;
	private Integer pcState;
	public Integer getPk_pcid() {
		return pk_pcid;
	}
	public void setPk_pcid(Integer pk_pcid) {
		this.pk_pcid = pk_pcid;
	}
	public Integer getPodid() {
		return podid;
	}
	public void setPodid(Integer podid) {
		this.podid = podid;
	}
	public String getPcTime() {
		return pcTime;
	}
	public void setPcTime(String pcTime) {
		this.pcTime = pcTime;
	}
	public String getPcContent() {
		return pcContent;
	}
	public void setPcContent(String pcContent) {
		this.pcContent = pcContent;
	}
	public Integer getPcUserid() {
		return pcUserid;
	}
	public void setPcUserid(Integer pcUserid) {
		this.pcUserid = pcUserid;
	}
	public String getPcUserName() {
		return pcUserName;
	}
	public void setPcUserName(String pcUserName) {
		this.pcUserName = pcUserName;
	}
	public Integer getPcLike() {
		return pcLike;
	}
	public void setPcLike(Integer pcLike) {
		this.pcLike = pcLike;
	}
	public Integer getPcReply() {
		return pcReply;
	}
	public void setPcReply(Integer pcReply) {
		this.pcReply = pcReply;
	}
	public List<PodcastReply> getPcReplyList() {
		return pcReplyList;
	}
	public void setPcReplyList(List<PodcastReply> pcReplyList) {
		this.pcReplyList = pcReplyList;
	}
	public Integer getPcState() {
		return pcState;
	}
	public void setPcState(Integer pcState) {
		this.pcState = pcState;
	}
	

	
	
}
