package com.gdupt.cominfo.pojo;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "Resource", description = "资源对象")
@SuppressWarnings("serial")
public class Resource implements Serializable {
	private Integer pk_resourceid;
	private String resourceType;
	private Integer download;
	private String link;
	private Integer resourceUserid;
	private Users resourceUser;
	private String resourceTime;
	private Integer resourceState;
	private String resourceTitle;
	private String resourceContent;
	private Integer resourcePoint;
	private Integer resourceLike;
	private Integer resourceCollect;
	public Integer getPk_resourceid() {
		return pk_resourceid;
	}
	public void setPk_resourceid(Integer pk_resourceid) {
		this.pk_resourceid = pk_resourceid;
	}
	public String getResourceType() {
		return resourceType;
	}
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}
	public Integer getDownload() {
		return download;
	}
	public void setDownload(Integer download) {
		this.download = download;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public Integer getResourceUserid() {
		return resourceUserid;
	}
	public void setResourceUserid(Integer resourceUserid) {
		this.resourceUserid = resourceUserid;
	}
	public Users getResourceUser() {
		return resourceUser;
	}
	public void setResourceUser(Users resourceUser) {
		this.resourceUser = resourceUser;
	}
	public String getResourceTime() {
		return resourceTime;
	}
	public void setResourceTime(String resourceTime) {
		this.resourceTime = resourceTime;
	}
	public Integer getResourceState() {
		return resourceState;
	}
	public void setResourceState(Integer resourceState) {
		this.resourceState = resourceState;
	}
	public String getResourceTitle() {
		return resourceTitle;
	}
	public void setResourceTitle(String resourceTitle) {
		this.resourceTitle = resourceTitle;
	}
	public String getResourceContent() {
		return resourceContent;
	}
	public void setResourceContent(String resourceContent) {
		this.resourceContent = resourceContent;
	}
	public Integer getResourcePoint() {
		return resourcePoint;
	}
	public void setResourcePoint(Integer resourcePoint) {
		this.resourcePoint = resourcePoint;
	}
	public Integer getResourceLike() {
		return resourceLike;
	}
	public void setResourceLike(Integer resourceLike) {
		this.resourceLike = resourceLike;
	}
	public Integer getResourceCollect() {
		return resourceCollect;
	}
	public void setResourceCollect(Integer resourceCollect) {
		this.resourceCollect = resourceCollect;
	}
	



}
