package com.gdupt.cominfo.pojo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Point implements Serializable{
	private Integer pk_pointid;
	private Integer pointType;
	private Integer pointUserid;
	private String pointWay;
	private String pointTime;
	private Integer pointNum;
	public Integer getPk_pointid() {
		return pk_pointid;
	}
	public void setPk_pointid(Integer pk_pointid) {
		this.pk_pointid = pk_pointid;
	}
	public Integer getPointType() {
		return pointType;
	}
	public void setPointType(Integer pointType) {
		this.pointType = pointType;
	}
	public Integer getPointUserid() {
		return pointUserid;
	}
	public void setPointUserid(Integer pointUserid) {
		this.pointUserid = pointUserid;
	}
	public String getPointWay() {
		return pointWay;
	}
	public void setPointWay(String pointWay) {
		this.pointWay = pointWay;
	}
	public String getPointTime() {
		return pointTime;
	}
	public void setPointTime(String pointTime) {
		this.pointTime = pointTime;
	}
	public Integer getPointNum() {
		return pointNum;
	}
	public void setPointNum(Integer pointNum) {
		this.pointNum = pointNum;
	}

	
}
