package com.gdupt.cominfo.pojo;

public class Data {
	Integer countData;
	Integer viewData;
	Integer likeData;
	Integer commentData;
	Integer pointData;
	Integer collectData;
	public Integer getCountData() {
		return countData;
	}
	public void setCountData(Integer countData) {
		this.countData = countData;
	}
	public Integer getViewData() {
		return viewData;
	}
	public void setViewData(Integer viewData) {
		this.viewData = viewData;
	}
	public Integer getLikeData() {
		return likeData;
	}
	public void setLikeData(Integer likeData) {
		this.likeData = likeData;
	}
	public Integer getCommentData() {
		return commentData;
	}
	public void setCommentData(Integer commentData) {
		this.commentData = commentData;
	}
	public Integer getPointData() {
		return pointData;
	}
	public void setPointData(Integer pointData) {
		this.pointData = pointData;
	}
	public Integer getCollectData() {
		return collectData;
	}
	public void setCollectData(Integer collectData) {
		this.collectData = collectData;
	}


}
