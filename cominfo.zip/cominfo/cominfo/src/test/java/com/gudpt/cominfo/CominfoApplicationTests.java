package com.gudpt.cominfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CominfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
